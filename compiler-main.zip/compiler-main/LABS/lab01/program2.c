#include<stdio.h>
int main(){
int a,b,c;
scanf(" %d",&a);
scanf(" %d",&b);
c=a+b;
printf("Sum of the two number is : %d  ", c);
return 0;
}
